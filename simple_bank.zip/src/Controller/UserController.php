<?php

namespace App\Controller;

use App\Entity\User;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class UserController extends AbstractController
{
    /**
     * @Route("/register", name="user")
     */
    public function index(Request $request)
    {
        if(!empty($this->getUser())){
            return $this->redirectToRoute('profile');
        }
        $error = '';
        $em = $this->getDoctrine()->getManager();
        if($request->getMethod() == 'POST'){
            $data = $request->request->all();
            $check = $em->getRepository(User::class)->findOneBy(['username' => $data['username']]);
            if(empty($check)){
                $check = $em->getRepository(User::class)->findOneBy(['email' => $data['email']]);
                if (empty($check)){
                    $check = $em->getRepository(User::class)->findOneBy(['phoneNumber' => $data['pNumber']]);
                    if (empty($check)) {
                        $user = New User();
                        $user->setGender($data['gender']);
                        $user->setFirstname($data['fName']);
                        $user->setLastname($data['lName']);
                        $user->setEmail($data['email']);
                        $user->setUsername($data['username']);
                        $user->setPlainPassword($data['pass']);
                        $user->setType($data['type']);
                        $user->setPhoneNumber($data['pNumber']);
                        $user->setEnabled(0);
                        $em->persist($user);
                        $em->flush();
                    }
                    else {
                        $error = 'Phone number already registered!';
                    }
                }
                else{
                    $error = 'Username already registered';
                }
            }
            else{
                $error = 'Email already registered';
            }
            $user = new User();
        }
        return $this->render('user/user.html.twig', [
            'error' => $error,
        ]);
    }
    /**
     * @Route("/profile", name="profile")
     */
    public function profile(){
        if(empty($this->getUser())){
            return $this->redirectToRoute('user');
        }
        return $this->render('user/profile.html.twig', [

        ]);
    }
    /**
     * @Route("/profile/edit", name="profile_edit")
     */
    public function profileEdit(Request $request){
        if(empty($this->getUser())){
            return $this->redirectToRoute('user');
        }
        $em = $this->getDoctrine()->getManager();
        if($request->getMethod() == 'POST'){
            $data = $request->request->all();
                        $user = $em->getRepository(User::class)->find($this->getUser()->getid());
                        $user->setGender($data['gender']);
                        $user->setFirstname($data['fName']);
                        $user->setLastname($data['lName']);
                        $user->setEmail($data['email']);
                        $user->setUsername($data['username']);
//                        $user->setPlainPassword($data['pass']);
                        $user->setType($data['type']);
                        $user->setPhoneNumber($data['pNumber']);
                        $user->setEnabled(1);
                        $em->flush();

        }
        return $this->render('user/user_edit.html.twig', [
        ]);
    }
}
