<?php

namespace App\Controller;

use App\Entity\Currency;
use App\Entity\Transaction;
use App\Entity\User;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class TransactionController extends AbstractController
{
    /**
     * @Route("/transaction", name="transaction")
     */
    public function index(Request $request)
    {
        $error = '';
        $em = $this->getDoctrine()->getManager();
        if($request->getMethod() == 'POST'){
            $data = $request->request->all();
            if($data['sender'] == $this->getUser()->getUserName()){
                $error = "You can't send money to own";
            }
            else{
                $sender = $em->getRepository(User::class)->findOneBy(['username' => $data['sender'] , 'enabled' => 1]);
                if(empty($sender)){
                    $error = 'Send username not found in database';
                }
                else{
                    $transaction = New Transaction();
                    $transaction->setAmount($data['amount']);
                    $transaction->setSender($sender);
                    $transaction->setReceiver($this->getUser());
                    $transaction->setCurrency($em->getRepository(Currency::class)->find($data['currency']));
                    $transaction->setDate(date('Y/m/d H:i:s'));
                    $em->persist($transaction);
                    $em->flush();
                    $error = 'Transaction send to ' . $sender->getFirstName() . ' ' . $sender->getLastName() . ' Successfully';
                }
            }
        }
        $currency = $em->getRepository(Currency::class)->findAll();
        return $this->render('transaction/transaction.html.twig', [
            'currency' => $currency,
            'error' => $error
        ]);
    }
}
